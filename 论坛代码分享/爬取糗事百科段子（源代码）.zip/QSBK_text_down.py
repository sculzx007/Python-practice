import urllib.request
import re
import os

import urllib.error

# 创建存放txt目录
path = os.getcwd()
new_path = os.path.join(path, 'QSBK')
if not os.path.exists(new_path):
    os.mkdir(new_path)

# 定义2个全局变量
x = 1
information =''

def open_url(url):
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36'}
    req = urllib.request.Request(url, headers=headers)
    response = urllib.request.urlopen(req)
    html = response.read().decode('utf-8', 'ignore')
    return html

def get_p_addrs(html):
    p = r'<a href="/article/(\d*)"'
    page_addrs = re.findall(p, html)
    page_addrs = list(set(page_addrs))
    print(page_addrs)
    return page_addrs

def find_information(html):
    pattren = re.compile(r'''<a href="/users/.*?/" target="_blank" title="(.*?)">.*?<div class="content">(.*?)</div>.*?<span class="stats-vote"><i class="number">(.*?)</i>''', re.S)
    items = re.findall(pattren, html)
    global information
    for item in items:

        replaceBR = re.compile('<br/>')
        text = re.sub(replaceBR, "\n", item[1])
        information = '\n\n发布人：'+item[0]+'\n发布内容：'+text.strip()+'\t  人气热度:'+item[2]
    return information


def find_god_text(html):
    pattren = re.compile(r'''<div class='cmt-name'>\s(.+?)\s</div>.*?<div class="main-text">(.*?)<''',re.S)
    answers = pattren.findall(html)
    god_text = ('\n共%d条神评论:' % len(answers))
    for answer in answers:
        text = '\n神评者:'+answer[0]+'\t神评内容:'+answer[1]+''
        god_text += text
    return god_text

def downloading():
    url = 'http://www.qiushibaike.com/hot/'
    for i in range(1, 35):
        try:
            page_url = url + str(i)
            html = open_url(page_url)
            page_addrs = get_p_addrs(html)
            print('# -*- ------正在爬取第%d页，获得共%d个链接------ -*- #' % (i+1, len(page_addrs)))
            for each in page_addrs:
                new_page_url = 'http://www.qiushibaike.com/article/' + each
                global x # 通过global方法，引入全局变量
                print('# -*- ------正在爬取第%d个链接中article号为%s的段子------ -*- #' % (x, each))
                print(new_page_url)
                html = open_url(new_page_url)
                information = find_information(html)
                god_text = find_god_text(html)
                os.chdir(new_path)
                with open('QSBK.txt', 'a') as f:
                    f.write(information + god_text)

        except urllib.error.URLError as e:
            if hasattr(e, 'code'):
                print(e.code, e.reason)
                continue
            elif hasattr(e, 'reason'):
                print(e.reason)
                continue


if __name__ == '__main__':

    downloading()
