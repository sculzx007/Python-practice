# _*_ coding: utf-8 _*_

"""
抓取豆瓣电影的全部数据
"""

from .movie_fetcher import MovieFetcher
from .movie_parser import MovieParser
from .movie_saver import MovieSaver
