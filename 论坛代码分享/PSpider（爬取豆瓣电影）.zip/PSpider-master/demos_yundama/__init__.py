# _*_ coding: utf-8 _*_

"""
封装关于YunDaMa的接口,识别验证码
"""

from .yundama import YunDaMa
