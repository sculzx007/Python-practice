# _*_ coding: utf-8 _*_

"""
从NBA官网http://stats.nba.com/获取球员数据
"""
