# _*_ coding: utf-8 _*_

"""
distributed module
"""
