# _*_ coding: utf-8 _*_

"""
define WebSpider, and define utilities and instances for web_spider
"""

from .utilities import *
from .instances import *
from .concurrent import WebSpider
