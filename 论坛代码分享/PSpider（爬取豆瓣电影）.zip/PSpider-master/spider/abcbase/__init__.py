# _*_ coding: utf-8 _*_

"""
define base classes which used in concurrent module and distributed module
"""

from .abc_base import TPEnum, BaseThread
