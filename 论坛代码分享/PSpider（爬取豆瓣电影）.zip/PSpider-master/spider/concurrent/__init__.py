# _*_ coding: utf-8 _*_

"""
define ThreadPool as WebSpider
"""

from .concur_threads import ThreadPool as WebSpider
